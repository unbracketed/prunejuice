#!/bin/bash
# Enhanced Context Gathering System for PruneJuice
# Provides comprehensive project and environment context collection

# Source required libraries
SCRIPT_DIR="$(dirname "${BASH_SOURCE[0]}")"

# Logging functions for independence
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2
}

log_debug() {
    if [[ "${PRUNEJUICE_LOG_LEVEL:-INFO}" == "DEBUG" ]]; then
        echo "[DEBUG] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2
    fi
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2
}

log_warn() {
    echo "[WARN] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2
}

# ============================================================================
# PROJECT CONTEXT GATHERING
# ============================================================================

# Gather comprehensive project context
gather_project_context() {
    local project_path="$1"
    local context_file="$2"
    
    log_info "Gathering project context for: $project_path"
    
    {
        echo "# Project Context Report"
        echo "Generated: $(date -u '+%Y-%m-%d %H:%M:%S UTC')"
        echo "Project: $(basename "$project_path")"
        echo "Path: $project_path"
        echo ""
        
        # Git information
        echo "## Git Repository Information"
        if [[ -d "$project_path/.git" ]]; then
            echo "Repository: $(git -C "$project_path" remote get-url origin 2>/dev/null || echo "local repository")"
            echo "Current branch: $(git -C "$project_path" branch --show-current 2>/dev/null || echo "unknown")"
            echo "Last commit: $(git -C "$project_path" log -1 --oneline 2>/dev/null || echo "none")"
            echo "Commit hash: $(git -C "$project_path" rev-parse HEAD 2>/dev/null || echo "unknown")"
            echo "Author: $(git -C "$project_path" log -1 --format='%an <%ae>' 2>/dev/null || echo "unknown")"
            echo "Date: $(git -C "$project_path" log -1 --format='%ad' --date=iso 2>/dev/null || echo "unknown")"
            
            # Working directory status
            echo ""
            echo "### Working Directory Status"
            local modified_files=$(git -C "$project_path" status --porcelain 2>/dev/null | wc -l | tr -d ' ')
            echo "Modified files: $modified_files"
            
            if [[ $modified_files -gt 0 ]]; then
                echo ""
                echo "#### Modified Files:"
                git -C "$project_path" status --porcelain 2>/dev/null | head -20
                if [[ $modified_files -gt 20 ]]; then
                    echo "... and $((modified_files - 20)) more files"
                fi
            fi
            
            # Recent commits
            echo ""
            echo "### Recent Commits (last 10)"
            git -C "$project_path" log --oneline -10 2>/dev/null || echo "No commit history"
            
        else
            echo "No git repository found"
        fi
        
        echo ""
        
        # Project structure analysis
        echo "## Project Structure"
        analyze_project_structure "$project_path"
        
        echo ""
        
        # Configuration files
        echo "## Configuration Files"
        find_configuration_files "$project_path"
        
        echo ""
        
        # Dependencies and tooling
        echo "## Dependencies and Tooling"
        analyze_project_dependencies "$project_path"
        
        echo ""
        
    } > "$context_file"
    
    log_info "Project context saved to: $context_file"
}

# Analyze project structure and identify key components
analyze_project_structure() {
    local project_path="$1"
    
    # Language detection based on files
    echo "### Language Analysis"
    detect_project_languages "$project_path"
    
    echo ""
    echo "### Directory Structure"
    find "$project_path" -type d -name ".git" -prune -o -type d -print | head -20 | sort
    
    echo ""
    echo "### Key Files"
    find_key_project_files "$project_path"
}

# Detect programming languages used in the project
detect_project_languages() {
    local project_path="$1"
    
    local file_counts
    file_counts=$(find "$project_path" -name ".git" -prune -o -type f -name "*.py" -o -name "*.js" -o -name "*.ts" -o -name "*.sh" -o -name "*.go" -o -name "*.java" -o -name "*.cpp" -o -name "*.c" -o -name "*.rs" -o -name "*.rb" -o -name "*.php" -print | \
        sed 's/.*\.//' | sort | uniq -c | sort -nr)
    
    if [[ -n "$file_counts" ]]; then
        echo "File types found:"
        echo "$file_counts" | while read count ext; do
            echo "  $ext: $count files"
        done
    else
        echo "No common programming language files detected"
    fi
}

# Find key project files
find_key_project_files() {
    local project_path="$1"
    
    # Common important files
    local key_files=(
        "README.md" "README.rst" "README.txt"
        "package.json" "requirements.txt" "Cargo.toml" "go.mod"
        "Dockerfile" "docker-compose.yml" "docker-compose.yaml"
        "Makefile" "CMakeLists.txt" "build.gradle"
        ".gitignore" ".env" ".env.example"
        "LICENSE" "CHANGELOG.md" "CONTRIBUTING.md"
    )
    
    echo "Important files found:"
    for file in "${key_files[@]}"; do
        if [[ -f "$project_path/$file" ]]; then
            echo "  ✓ $file"
        fi
    done
}

# Find configuration files
find_configuration_files() {
    local project_path="$1"
    
    echo "Configuration files:"
    find "$project_path" -maxdepth 3 -name ".git" -prune -o \( \
        -name "*.json" -o -name "*.yaml" -o -name "*.yml" -o \
        -name "*.toml" -o -name "*.ini" -o -name "*.conf" \
    \) -type f -print | head -10
}

# Analyze project dependencies
analyze_project_dependencies() {
    local project_path="$1"
    
    # Node.js
    if [[ -f "$project_path/package.json" ]]; then
        echo "### Node.js Dependencies"
        if command -v jq &> /dev/null; then
            echo "Production dependencies: $(jq -r '.dependencies // {} | keys | length' "$project_path/package.json")"
            echo "Dev dependencies: $(jq -r '.devDependencies // {} | keys | length' "$project_path/package.json")"
        else
            echo "package.json found (install jq for detailed analysis)"
        fi
        echo ""
    fi
    
    # Python
    if [[ -f "$project_path/requirements.txt" ]]; then
        echo "### Python Dependencies"
        echo "Requirements.txt dependencies: $(wc -l < "$project_path/requirements.txt")"
        echo ""
    fi
    
    if [[ -f "$project_path/setup.py" ]] || [[ -f "$project_path/pyproject.toml" ]]; then
        echo "### Python Package"
        echo "Python package structure detected"
        echo ""
    fi
    
    # Rust
    if [[ -f "$project_path/Cargo.toml" ]]; then
        echo "### Rust Dependencies"
        echo "Cargo.toml found"
        echo ""
    fi
    
    # Go
    if [[ -f "$project_path/go.mod" ]]; then
        echo "### Go Module"
        echo "Go module: $(grep '^module ' "$project_path/go.mod" | cut -d' ' -f2)"
        echo ""
    fi
}

# ============================================================================
# GITHUB INTEGRATION
# ============================================================================

# Gather GitHub issue context
gather_issue_context() {
    local issue_number="$1"
    local context_file="$2"
    
    log_info "Gathering GitHub issue context for issue #$issue_number"
    
    {
        echo "# GitHub Issue Context"
        echo "Issue: #$issue_number"
        echo "Retrieved: $(date -u '+%Y-%m-%d %H:%M:%S UTC')"
        echo ""
        
        if command -v gh &> /dev/null; then
            # Get issue details
            echo "## Issue Details"
            gh issue view "$issue_number" --json title,body,state,labels,assignees,createdAt,updatedAt 2>/dev/null | \
                jq -r '"Title: " + .title, "State: " + .state, "Created: " + .createdAt, "Updated: " + .updatedAt, "", "Labels:", (.labels[]?.name // "none"), "", "Assignees:", (.assignees[]?.login // "none"), "", "Description:", .body' || \
                echo "Failed to fetch issue details"
            
            echo ""
            
            # Get recent comments
            echo "## Recent Comments"
            gh issue view "$issue_number" --comments --json comments 2>/dev/null | \
                jq -r '.comments[-5:][]? | "**" + .author.login + "** (" + .createdAt + "):\n" + .body + "\n"' || \
                echo "No comments or failed to fetch"
            
            echo ""
            
            # Related issues
            echo "## Related Issues"
            gh issue list --limit 5 --search "is:issue is:open" --json number,title,state 2>/dev/null | \
                jq -r '.[] | "#" + (.number | tostring) + " - " + .title + " (" + .state + ")"' || \
                echo "Failed to fetch related issues"
                
        else
            echo "GitHub CLI (gh) not available - install for GitHub integration"
        fi
        
    } >> "$context_file"
    
    log_info "GitHub issue context appended to: $context_file"
}

# Gather GitHub repository context
gather_repository_context() {
    local context_file="$1"
    
    {
        echo "## GitHub Repository Context"
        
        if command -v gh &> /dev/null; then
            # Repository information
            gh repo view --json name,description,defaultBranch,isPrivate,pushedAt,stargazerCount 2>/dev/null | \
                jq -r '"Repository: " + .name, "Description: " + (.description // "none"), "Default branch: " + .defaultBranch, "Private: " + (.isPrivate | tostring), "Last pushed: " + .pushedAt, "Stars: " + (.stargazerCount | tostring)' || \
                echo "Failed to fetch repository details"
            
            echo ""
            
            # Recent pull requests
            echo "### Recent Pull Requests"
            gh pr list --limit 5 --json number,title,state,createdAt 2>/dev/null | \
                jq -r '.[] | "#" + (.number | tostring) + " - " + .title + " (" + .state + ", " + .createdAt + ")"' || \
                echo "No recent pull requests or failed to fetch"
                
        else
            echo "GitHub CLI not available"
        fi
        
        echo ""
        
    } >> "$context_file"
}

# ============================================================================
# ENVIRONMENT CONTEXT
# ============================================================================

# Gather environment and system context
gather_environment_context() {
    local context_file="$1"
    
    {
        echo "## Environment Context"
        echo "Hostname: $(hostname)"
        echo "User: $(whoami)"
        echo "Operating System: $(uname -s)"
        echo "Architecture: $(uname -m)"
        echo "Kernel: $(uname -r)"
        echo "Shell: $SHELL"
        echo "PWD: $PWD"
        echo ""
        
        echo "### Tool Availability"
        check_tool_availability
        
        echo ""
        
        echo "### PruneJuice Environment"
        env | grep -E '^PRUNEJUICE_' | sort || echo "No PruneJuice environment variables set"
        
        echo ""
        
    } >> "$context_file"
}

# Check availability of common development tools
check_tool_availability() {
    local tools=("git" "docker" "node" "npm" "python" "pip" "go" "cargo" "make" "cmake" "jq" "yq" "gh")
    
    for tool in "${tools[@]}"; do
        if command -v "$tool" &> /dev/null; then
            local version=$(command "$tool" --version 2>/dev/null | head -n1 || echo "unknown")
            echo "  ✓ $tool: $version"
        else
            echo "  ✗ $tool: not available"
        fi
    done
}

# ============================================================================
# COMPREHENSIVE CONTEXT GATHERING
# ============================================================================

# Gather all available context
gather_comprehensive_context() {
    local project_path="${1:-$PWD}"
    local output_file="${2:-context.md}"
    local issue_number="${3:-}"
    
    log_info "Gathering comprehensive context"
    
    # Initialize context file
    echo "# Comprehensive Context Report" > "$output_file"
    echo "Generated by PruneJuice Context Gathering System" >> "$output_file"
    echo "" >> "$output_file"
    
    # Gather project context
    gather_project_context "$project_path" "$output_file"
    
    # Gather environment context
    gather_environment_context "$output_file"
    
    # Gather GitHub repository context
    gather_repository_context "$output_file"
    
    # Gather specific issue context if provided
    if [[ -n "$issue_number" ]]; then
        gather_issue_context "$issue_number" "$output_file"
    fi
    
    log_info "Comprehensive context saved to: $output_file"
    echo "$output_file"
}

# ============================================================================
# INITIALIZATION
# ============================================================================

# Initialize context gathering system
init_context_gathering() {
    log_debug "Context gathering system initialized"
}