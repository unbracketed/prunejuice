#!/bin/bash
# Tool Integration Layer for PruneJuice
# Provides wrapper functions for plum (worktree manager) and pots (tmux session manager)

# Source required libraries
SCRIPT_DIR="$(dirname "${BASH_SOURCE[0]}")"
source "$SCRIPT_DIR/database.sh"

# Logging functions (duplicated from executor.sh for independence)
log_info() {
    echo "[INFO] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2
}

log_debug() {
    if [[ "${PRUNEJUICE_LOG_LEVEL:-INFO}" == "DEBUG" ]]; then
        echo "[DEBUG] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2
    fi
}

log_error() {
    echo "[ERROR] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2
}

log_warn() {
    echo "[WARN] $(date '+%Y-%m-%d %H:%M:%S') $*" >&2
}

# Tool availability flags
PLUM_AVAILABLE=""
POTS_AVAILABLE=""

# Initialize tool availability detection
init_tool_integration() {
    detect_tool_availability
}

# Detect available tools
detect_tool_availability() {
    local script_base_dir
    script_base_dir="$(dirname "$SCRIPT_DIR")"
    
    # Check for plum
    if [[ -x "$script_base_dir/../plum-cli.sh" ]]; then
        PLUM_AVAILABLE="true"
        log_debug "Plum CLI found at: $script_base_dir/../plum-cli.sh"
    else
        PLUM_AVAILABLE="false"
        log_debug "Plum CLI not found"
    fi
    
    # Check for pots
    if [[ -x "$script_base_dir/../pots/pots" ]]; then
        POTS_AVAILABLE="true"
        log_debug "Pots CLI found at: $script_base_dir/../pots/pots"
    else
        POTS_AVAILABLE="false"
        log_debug "Pots CLI not found"
    fi
    
    log_info "Tool availability - Plum: $PLUM_AVAILABLE, Pots: $POTS_AVAILABLE"
}

# Validate that required tools are available
validate_tool_availability() {
    local required_tools=("$@")
    local missing_tools=()
    
    for tool in "${required_tools[@]}"; do
        case "$tool" in
            "plum")
                if [[ "$PLUM_AVAILABLE" != "true" ]]; then
                    missing_tools+=("plum")
                fi
                ;;
            "pots")
                if [[ "$POTS_AVAILABLE" != "true" ]]; then
                    missing_tools+=("pots")
                fi
                ;;
            *)
                log_warn "Unknown tool specified for validation: $tool"
                ;;
        esac
    done
    
    if [[ ${#missing_tools[@]} -gt 0 ]]; then
        log_error "Missing required tools: ${missing_tools[*]}"
        return 1
    fi
    
    return 0
}

# ============================================================================
# PLUM INTEGRATION FUNCTIONS
# ============================================================================

# Create worktree using plum and return worktree path
plum_create_worktree() {
    local branch_name="$1"
    local project_path="${2:-$PWD}"
    local worktree_path=""
    
    if [[ "$PLUM_AVAILABLE" != "true" ]]; then
        log_error "Plum is not available for worktree creation"
        return 1
    fi
    
    if [[ -z "$branch_name" ]]; then
        log_error "Branch name is required for worktree creation"
        return 1
    fi
    
    log_info "Creating worktree for branch: $branch_name"
    
    local script_base_dir
    script_base_dir="$(dirname "$SCRIPT_DIR")"
    local plum_cli="$script_base_dir/../plum-cli.sh"
    
    # Execute plum create command and capture output
    local plum_output
    if plum_output=$("$plum_cli" create "$branch_name" 2>&1); then
        # Extract worktree path from plum output
        # Assuming plum returns the worktree path on the last line
        worktree_path=$(echo "$plum_output" | tail -n 1 | grep -E '^/.*' || echo "")
        
        if [[ -n "$worktree_path" && -d "$worktree_path" ]]; then
            log_info "Worktree created successfully: $worktree_path"
            
            # Record worktree in database
            record_worktree_creation "$worktree_path" "$branch_name" "$project_path"
            
            echo "$worktree_path"
            return 0
        else
            log_error "Failed to determine worktree path from plum output"
            log_error "Plum output: $plum_output"
            return 1
        fi
    else
        log_error "Plum worktree creation failed"
        log_error "Plum output: $plum_output"
        return 1
    fi
}

# List active worktrees using plum
plum_list_worktrees() {
    if [[ "$PLUM_AVAILABLE" != "true" ]]; then
        log_error "Plum is not available for worktree listing"
        return 1
    fi
    
    local script_base_dir
    script_base_dir="$(dirname "$SCRIPT_DIR")"
    local plum_cli="$script_base_dir/../plum-cli.sh"
    
    log_debug "Listing worktrees using plum"
    "$plum_cli" list
}

# Clean up worktree using plum
plum_cleanup_worktree() {
    local worktree_path="$1"
    
    if [[ "$PLUM_AVAILABLE" != "true" ]]; then
        log_error "Plum is not available for worktree cleanup"
        return 1
    fi
    
    if [[ -z "$worktree_path" ]]; then
        log_error "Worktree path is required for cleanup"
        return 1
    fi
    
    log_info "Cleaning up worktree: $worktree_path"
    
    local script_base_dir
    script_base_dir="$(dirname "$SCRIPT_DIR")"
    local plum_cli="$script_base_dir/../plum-cli.sh"
    
    # Extract branch name from worktree path for plum cleanup
    local branch_name
    branch_name=$(basename "$worktree_path")
    
    if "$plum_cli" cleanup "$branch_name"; then
        log_info "Worktree cleaned up successfully: $worktree_path"
        
        # Update database record
        record_worktree_cleanup "$worktree_path"
        
        return 0
    else
        log_error "Failed to cleanup worktree: $worktree_path"
        return 1
    fi
}

# ============================================================================
# POTS INTEGRATION FUNCTIONS  
# ============================================================================

# Create tmux session using pots and return session name
pots_create_session() {
    local worktree_path="$1"
    local task_name="${2:-dev}"
    local session_name=""
    
    if [[ "$POTS_AVAILABLE" != "true" ]]; then
        log_error "Pots is not available for session creation"
        return 1
    fi
    
    if [[ -z "$worktree_path" ]]; then
        log_error "Worktree path is required for session creation"
        return 1
    fi
    
    if [[ ! -d "$worktree_path" ]]; then
        log_error "Worktree path does not exist: $worktree_path"
        return 1
    fi
    
    log_info "Creating tmux session for worktree: $worktree_path"
    
    local script_base_dir
    script_base_dir="$(dirname "$SCRIPT_DIR")"
    local pots_cli="$script_base_dir/../pots/pots"
    
    # Execute pots create command and capture session name
    local pots_output
    if pots_output=$("$pots_cli" create "$worktree_path" "$task_name" 2>&1); then
        # Extract session name from pots output
        # Assuming pots returns the session name on the last line
        session_name=$(echo "$pots_output" | tail -n 1 | grep -E '^[a-zA-Z0-9_-]+$' || echo "")
        
        if [[ -n "$session_name" ]]; then
            log_info "Tmux session created successfully: $session_name"
            
            # Record session in database
            record_session_creation "$session_name" "$worktree_path" "$task_name"
            
            echo "$session_name"
            return 0
        else
            log_error "Failed to determine session name from pots output"
            log_error "Pots output: $pots_output"
            return 1
        fi
    else
        log_error "Pots session creation failed"
        log_error "Pots output: $pots_output"
        return 1
    fi
}

# List active sessions using pots
pots_list_sessions() {
    if [[ "$POTS_AVAILABLE" != "true" ]]; then
        log_error "Pots is not available for session listing"
        return 1
    fi
    
    local script_base_dir
    script_base_dir="$(dirname "$SCRIPT_DIR")"
    local pots_cli="$script_base_dir/../pots/pots"
    
    log_debug "Listing sessions using pots"
    "$pots_cli" list
}

# Clean up tmux session using pots
pots_cleanup_session() {
    local session_name="$1"
    
    if [[ "$POTS_AVAILABLE" != "true" ]]; then
        log_error "Pots is not available for session cleanup"
        return 1
    fi
    
    if [[ -z "$session_name" ]]; then
        log_error "Session name is required for cleanup"
        return 1
    fi
    
    log_info "Cleaning up tmux session: $session_name"
    
    local script_base_dir
    script_base_dir="$(dirname "$SCRIPT_DIR")"
    local pots_cli="$script_base_dir/../pots/pots"
    
    if "$pots_cli" cleanup "$session_name"; then
        log_info "Session cleaned up successfully: $session_name"
        
        # Update database record
        record_session_cleanup "$session_name"
        
        return 0
    else
        log_error "Failed to cleanup session: $session_name"
        return 1
    fi
}

# Attach to existing session using pots
pots_attach_session() {
    local session_name="$1"
    
    if [[ "$POTS_AVAILABLE" != "true" ]]; then
        log_error "Pots is not available for session attachment"
        return 1
    fi
    
    if [[ -z "$session_name" ]]; then
        log_error "Session name is required for attachment"
        return 1
    fi
    
    log_info "Attaching to tmux session: $session_name"
    
    local script_base_dir
    script_base_dir="$(dirname "$SCRIPT_DIR")"
    local pots_cli="$script_base_dir/../pots/pots"
    
    "$pots_cli" attach "$session_name"
}

# ============================================================================
# DATABASE INTEGRATION FUNCTIONS
# ============================================================================

# Record worktree creation in database
record_worktree_creation() {
    local worktree_path="$1"
    local branch_name="$2"
    local project_path="$3"
    
    local metadata="{\"tool\":\"plum\",\"action\":\"create\",\"branch\":\"$branch_name\",\"project\":\"$project_path\"}"
    
    log_debug "Recording worktree creation: $worktree_path"
    
    # Use existing database functions if available
    if command -v start_event &> /dev/null; then
        start_event "plum-create-worktree" "$project_path" "$branch_name" "" "$worktree_path" "$metadata"
    fi
}

# Record worktree cleanup in database  
record_worktree_cleanup() {
    local worktree_path="$1"
    
    log_debug "Recording worktree cleanup: $worktree_path"
    
    # Update any active events related to this worktree
    # This would require additional database schema enhancements
}

# Record session creation in database
record_session_creation() {
    local session_name="$1"
    local worktree_path="$2"
    local task_name="$3"
    
    log_debug "Recording session creation: $session_name"
    
    # Use existing session management functions
    if command -v create_session &> /dev/null; then
        create_session "$session_name" "$(dirname "$worktree_path")" "$(basename "$worktree_path")" "$session_name"
    fi
}

# Record session cleanup in database
record_session_cleanup() {
    local session_name="$1"
    
    log_debug "Recording session cleanup: $session_name"
    
    # Use existing session management functions  
    if command -v kill_session &> /dev/null; then
        kill_session "$session_name"
    fi
}

# ============================================================================
# HIGH-LEVEL ORCHESTRATION FUNCTIONS
# ============================================================================

# Create complete development environment (worktree + session)
create_development_environment() {
    local branch_name="$1"
    local project_path="${2:-$PWD}"
    local task_name="${3:-dev}"
    
    log_info "Creating complete development environment for branch: $branch_name"
    
    # Validate required tools
    if ! validate_tool_availability "plum" "pots"; then
        log_error "Required tools not available for development environment creation"
        return 1
    fi
    
    # Create worktree
    local worktree_path
    if ! worktree_path=$(plum_create_worktree "$branch_name" "$project_path"); then
        log_error "Failed to create worktree for development environment"
        return 1
    fi
    
    # Create session
    local session_name
    if ! session_name=$(pots_create_session "$worktree_path" "$task_name"); then
        log_error "Failed to create session for development environment"
        # Clean up worktree on session creation failure
        plum_cleanup_worktree "$worktree_path"
        return 1
    fi
    
    log_info "Development environment created successfully"
    log_info "Worktree: $worktree_path"
    log_info "Session: $session_name"
    
    # Return both worktree path and session name
    echo "$worktree_path|$session_name"
    return 0
}

# Clean up complete development environment
cleanup_development_environment() {
    local worktree_path="$1"
    local session_name="$2"
    
    log_info "Cleaning up development environment"
    
    local cleanup_success=true
    
    # Clean up session first
    if [[ -n "$session_name" ]]; then
        if ! pots_cleanup_session "$session_name"; then
            log_warn "Session cleanup failed: $session_name"
            cleanup_success=false
        fi
    fi
    
    # Clean up worktree
    if [[ -n "$worktree_path" ]]; then
        if ! plum_cleanup_worktree "$worktree_path"; then
            log_warn "Worktree cleanup failed: $worktree_path"
            cleanup_success=false
        fi
    fi
    
    if [[ "$cleanup_success" == "true" ]]; then
        log_info "Development environment cleaned up successfully"
        return 0
    else
        log_error "Development environment cleanup completed with errors"
        return 1
    fi
}

# ============================================================================
# INITIALIZATION
# ============================================================================

# Initialize tool integration when sourced
init_tool_integration